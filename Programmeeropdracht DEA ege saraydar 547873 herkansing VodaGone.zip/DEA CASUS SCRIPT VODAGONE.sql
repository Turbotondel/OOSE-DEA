Create table abonnee (
	abonneenaam varchar(255) not null,
    emailadres varchar(255)  not null,
    primary key (abonneenaam)
);

Create table dienst (
	bedrijf   varchar(255)not null,
    dienstnaam  varchar(255)not null,
    beschrijving varchar(255)not null,
    maandprijs  integer  not null,
    halfjaarprijs integer  not null,
    jaarprijs  integer  not null,
    deelbaar  boolean   not null,
    verdubbelbaar boolean   not null,
    primary key (dienstnaam)
);


Create table abonnement (
	abonneenaam  varchar(255) not null,
    dienstnaam  varchar(255) not null,
    abonneedelen1  varchar(255)  null,
	abonneedelen2  varchar(255)  null,  
	startdatum   date   not null,
    verdubbeld   boolean    not null,
    abonnementsoort enum('MAAND', 'HALFJAAR', 'JAAR'),
    abonnementstatus enum('PROEF', 'ACTIEF', 'OPGEZEGD'),
    primary key (abonneenaam, dienstnaam),
    foreign key (abonneenaam) references abonnee(abonneenaam) on delete cascade on update cascade,
    foreign key (abonneedelen1) references abonnee(abonneenaam) on delete cascade on update cascade,
    foreign key (abonneedelen2) references abonnee(abonneenaam) on delete cascade on update cascade,
    foreign key (dienstnaam) references dienst(dienstnaam) on delete cascade on update cascade
);


insert into abonnee (abonneenaam, emailadres)
values("Jorg Lubbers", "jorglubbers@hotmail.com"),
("Ege Saraydar", "egesaraydar@hotmail.com"),
("Jordy Veldhuizen", "jordyveldhuizen@hotmail.com");


insert into dienst (bedrijf, dienstnaam, beschrijving, maandprijs, halfjaarprijs, jaarprijs, deelbaar, verdubbelbaar)
values("Vodafone", "Mobiele telefonie 100", "100 minuten, SMS of GB", 5, 25, 45, false, false),
("Vodafone", "Mobiele telefonie 250", "250 minuten, SMS of GB", 10, 50, 90, false, true),
("Vodafone", "Glasvezel-internet", "download 500 Mbps", 40, 200, 360, false, true),
("Ziggo", "Kabel-internet", "download 300 Mbps", 30, 150, 270, false, false),
("Ziggo", "Eredivisie Live 1,2,3,4 en 5", "beschrijving", 10, 50, 90, true, false),
("Ziggo", "HBO Plus", "HBO Plus - beschrijving", 15, 75, 135, true, false);

insert into abonnement (abonneenaam, dienstnaam, abonneedelen1, abonneedelen2, startdatum, verdubbeld, abonnementsoort, abonnementstatus)
values("Jorg Lubbers", "Mobiele telefonie 250", "Ege Saraydar", "Jordy Veldhuizen", "2016-01-01", false, 'MAAND', 'ACTIEF'),
("Jorg Lubbers", "Glasvezel-internet", null, null, "2016-02-05", true, 'JAAR', 'ACTIEF'),
("Jordy Veldhuizen", "Mobiele telefonie 250", "Ege Saraydar", null, "2015-01-01", false, 'MAAND', 'ACTIEF'),
("Ege Saraydar", "Eredivisie Live 1,2,3,4 en 5", "Jorg Lubbers", null, "2013-10-11", true, 'HALFJAAR', 'ACTIEF'),
("Ege Saraydar", "Glasvezel-internet", "Jorg Lubbers", null, "2016-08-21", false, 'MAAND', 'PROEF'),
("Jorg Lubbers", "Kabel-internet", "Jorg Lubbers", null, "2015-03-31", true, 'MAAND', 'ACTIEF'),
("Jordy Veldhuizen", "Mobiele telefonie 100", "Jorg Lubbers", null, "2016-01-01", true, 'HALFJAAR', 'PROEF')



