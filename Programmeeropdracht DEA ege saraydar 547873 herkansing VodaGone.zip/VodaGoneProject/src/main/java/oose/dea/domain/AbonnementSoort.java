package oose.dea.domain;

/**
 * Created by nymtesx on 18-10-2016.
 */
public enum AbonnementSoort {
    MAAND,
    HALFJAAR,
    JAAR;

}