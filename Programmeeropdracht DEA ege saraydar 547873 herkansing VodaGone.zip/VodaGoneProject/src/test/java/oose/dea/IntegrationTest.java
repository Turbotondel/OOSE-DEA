package oose.dea;

public interface IntegrationTest {
}
